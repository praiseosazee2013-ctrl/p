const SKEY='futurepath_2_state';
let state=JSON.parse(localStorage.getItem(SKEY)||'null')||{
 user:null,xp:0,saved:[],completed:0,quizCorrect:0,quizTotal:0,
 activity:[],tasks:[]
};
const subjects=[
['Maths','∑','Algebra • Number • Geometry',['Algebra','Quadratics','Probability']],
['English Language','Aa','Reading • Writing • Analysis',['Creative writing','Language analysis','Paper 1 practice']],
['English Literature','✒','Texts • Poetry • Themes',['Macbeth','An Inspector Calls','Poetry']],
['Biology','🧬','Cells • Ecology • Genetics',['Cells','Photosynthesis','Genetics']],
['Chemistry','⚗','Atoms • Reactions • Energy',['Atomic structure','Bonding','Chemical reactions']],
['Physics','⚡','Forces • Energy • Electricity',['Forces','Energy','Electricity']],
['Computer Science','</>','Algorithms • Data • Programming',['Algorithms','Networks','Programming']],
['History','🏛','Periods • Causes • Consequences',['Medicine through time','Elizabethan England','Conflict and tension']],
['Geography','🌍','Physical • Human • Fieldwork',['Natural hazards','Urban issues','The living world']],
['French','🇫🇷','Vocabulary • Grammar • Speaking',['Identity and culture','Local area','School']],
['Art & Design','🎨','Portfolio • Research • Techniques',['Artist research','Developing ideas','Final outcome']],
['Business','📊','Marketing • Finance • Operations',['Marketing','Finance','Business operations']]
];
const careers=[
['Software Developer','Technology','Computer Science, Maths','Build software, websites and applications.',['Problem solving','Programming','Creativity']],
['Doctor','Healthcare','Biology, Chemistry, Maths','Diagnose and treat patients as part of a healthcare team.',['Communication','Science','Decision making']],
['Architect','Design','Maths, Art, Physics','Design buildings and spaces while balancing creativity and technical requirements.',['Design','Maths','Communication']],
['Engineer','Engineering','Maths, Physics, Computer Science','Design and improve products, machines, structures or systems.',['Maths','Problem solving','Teamwork']],
['Lawyer','Law','English, History','Research evidence and construct clear legal arguments.',['Communication','Analysis','Research']],
['Teacher','Education','Any strong subject','Help learners understand ideas and develop confidence.',['Communication','Organisation','Patience']],
['Data Analyst','Technology','Maths, Computer Science','Use data to answer questions and support decisions.',['Statistics','Technology','Critical thinking']],
['Graphic Designer','Creative','Art, Computer Science','Create visual concepts for digital and print communication.',['Design','Creativity','Technology']],
['Psychologist','Healthcare','Biology, Maths','Study behaviour and use evidence to understand people and wellbeing.',['Research','Analysis','Communication']],
['Environmental Scientist','Environment','Biology, Chemistry, Geography','Investigate environmental problems and support sustainable solutions.',['Science','Fieldwork','Analysis']],
['Cyber Security Analyst','Technology','Computer Science, Maths','Help organisations protect systems, networks and information.',['Problem solving','Technology','Attention to detail']],
['Journalist','Media','English, History','Research stories, verify information and communicate clearly.',['Writing','Research','Curiosity']]
];
let careerFilter='All';
function save(){localStorage.setItem(SKEY,JSON.stringify(state));renderAll()}
function toast(t){const e=document.getElementById('toast');e.textContent=t;e.classList.add('show');setTimeout(()=>e.classList.remove('show'),1800)}
function showPage(id){document.querySelectorAll('.page').forEach(x=>x.classList.remove('active'));document.getElementById(id).classList.add('active');window.scrollTo({top:0,behavior:'smooth'});renderAll()}
function renderSubjects(){const q=(document.getElementById('subjectSearch')?.value||'').toLowerCase();document.getElementById('subjectsGrid').innerHTML=subjects.filter(s=>s.join(' ').toLowerCase().includes(q)).map((s,i)=>`<article class="subject-card" onclick="openSubject(${i})"><div class="icon">${s[1]}</div><h3>${s[0]}</h3><p>${s[2]}</p><small>${s[3].length} topics • Click to explore</small></article>`).join('')}
function openSubject(i){const s=subjects[i];document.getElementById('topicPanel').classList.remove('hidden');document.getElementById('topicPanel').innerHTML=`<p class="eyebrow">${s[0].toUpperCase()}</p><h2>${s[0]} topics</h2><p>Choose a topic to study. Each topic can later be connected to your school's real resources and quizzes.</p><div class="topic-grid">${s[3].map((t,j)=>`<div class="topic"><b>${t}</b><p>Learn key ideas, then test your recall.</p><button class="secondary" onclick="startTopic('${t.replaceAll("'","")}')">Start topic</button></div>`).join('')}</div>`;document.getElementById('topicPanel').scrollIntoView({behavior:'smooth'})}
function startTopic(t){state.xp+=5;state.activity.unshift({text:`Explored ${t}`,xp:5});save();toast(`Started ${t} • +5 XP`);showPage('coach');document.getElementById('coachInput').value=`Help me revise ${t} for GCSE. Give me a short explanation and 5 practice questions.`}
function renderCareerFilters(){const fs=['All',...new Set(careers.map(c=>c[1]))];document.getElementById('careerFilters').innerHTML=fs.map(f=>`<button class="filter ${f===careerFilter?'active':''}" onclick="careerFilter='${f}';renderCareerFilters();renderCareers()">${f}</button>`).join('')}
function renderCareers(){const q=(document.getElementById('careerSearch')?.value||'').toLowerCase();document.getElementById('careerGrid').innerHTML=careers.filter(c=>(careerFilter==='All'||c[1]===careerFilter)&&c.join(' ').toLowerCase().includes(q)).map((c,i)=>`<article class="career-card" onclick="careerAction(${i})"><button class="save" onclick="event.stopPropagation();toggleSave(${i})">${state.saved.includes(i)?'★':'☆'}</button><span class="tag">${c[1]}</span><h3>${c[0]}</h3><b>${c[2]}</b><p>${c[3]}</p><small>Skills: ${c[4].join(' • ')}</small></article>`).join('')}
function toggleSave(i){const p=state.saved.indexOf(i);if(p>=0){state.saved.splice(p,1);toast('Removed from saved careers')}else{state.saved.push(i);state.xp+=10;state.activity.unshift({text:`Saved career: ${careers[i][0]}`,xp:10});toast(`Saved ${careers[i][0]} • +10 XP`)}save()}
function careerAction(i){const c=careers[i];state.xp+=3;state.activity.unshift({text:`Explored career: ${c[0]}`,xp:3});save();alert(`${c[0]}\n\nSector: ${c[1]}\n\nUseful GCSEs: ${c[2]}\n\n${c[3]}\n\nSkills: ${c[4].join(', ')}\n\nNext: research sixth-form/college subjects, apprenticeships and university routes relevant to this career.`)}
function coachPrompt(t){document.getElementById('coachInput').value=t;sendCoach()}
function sendCoach(){const input=document.getElementById('coachInput');const text=input.value.trim();if(!text)return;const chat=document.getElementById('chat');chat.innerHTML+=`<div class="message user">${escapeHtml(text)}</div>`;let reply;if(/plan/i.test(text))reply='Try this structure: 5 min recall → 15 min focused revision → 10 min practice questions → 5 min mark and correct. Finish by writing three things you still need to remember.';else if(/question|practice/i.test(text))reply='Practice set: 1) Define the key term. 2) Explain the main process. 3) Apply it to a new example. 4) Compare two ideas. 5) Explain one common mistake and how to avoid it.';else reply='Start with the core idea, then test yourself without notes. I can also help you turn this into a revision plan or practice questions. For production, this message would be sent to your secure server-side AI endpoint.';chat.innerHTML+=`<div class="message bot"><b>Study Coach</b><br>${reply}</div>`;chat.scrollTop=chat.scrollHeight;input.value='';state.xp+=3;state.activity.unshift({text:'Used Study Coach',xp:3});save()}
function escapeHtml(s){return s.replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[m]))}
function level(){return Math.floor(state.xp/100)+1}
function renderProgress(){const lvl=level(),within=state.xp%100;document.getElementById('bigLevel').textContent=lvl;document.getElementById('levelCopy').textContent=`${100-within} XP until Level ${lvl+1}.`;document.getElementById('largeXP').style.width=within+'%';const pct=Math.min(100,state.completed*10+state.saved.length*5);document.getElementById('overallProgress').textContent=pct+'%';document.getElementById('overallMeter').style.width=pct+'%';const badges=[['First steps',state.xp>=5],['Career explorer',state.saved.length>=1],['Revision builder',state.xp>=50],['Level 2',lvl>=2],['Career planner',state.saved.length>=3],['Study Coach',state.activity.some(a=>a.text==='Used Study Coach')]];document.getElementById('badges').innerHTML=badges.map(b=>`<div class="badge ${b[1]?'':'locked'}"><b>${b[1]?'🏆':'🔒'} ${b[0]}</b><p>${b[1]?'Unlocked':'Keep learning to unlock'}</p></div>`).join('');document.getElementById('activity').innerHTML=state.activity.slice(0,10).map(a=>`<div class="activity-row"><span>${a.text}</span><b>+${a.xp} XP</b></div>`).join('')||'<div class="activity-row">No activity yet. Start exploring!</div>'}
function renderAll(){const lvl=level(),within=state.xp%100;document.getElementById('xpValue').textContent=state.xp;document.getElementById('levelValue').textContent=lvl;document.getElementById('savedValue').textContent=state.saved.length;document.getElementById('quizAccuracy').textContent=state.quizTotal?Math.round(state.quizCorrect/state.quizTotal*100)+'%':'0%';document.getElementById('weekProgress').textContent=Math.min(100,state.completed*10)+'%';document.getElementById('heroLevel').textContent=lvl;document.getElementById('heroXP').style.width=within+'%';document.getElementById('heroXPText').textContent=`${within} / 100 XP to next level`;document.getElementById('userChip').textContent=state.user||'Guest';document.getElementById('adminNav').classList.toggle('hidden',state.user!=='Admin');renderSubjects();renderCareerFilters();renderCareers();renderProgress()}
function openAuth(){document.getElementById('authModal').classList.remove('hidden')}
function closeAuth(){document.getElementById('authModal').classList.add('hidden')}
function demoLogin(){const n=document.getElementById('authName').value.trim();if(!n){document.getElementById('authError').textContent='Please enter your first name.';return}state.user=n;state.xp+=10;state.activity.unshift({text:'Created demo student profile',xp:10});closeAuth();save();toast(`Welcome, ${n}! +10 XP`)}
renderAll();
