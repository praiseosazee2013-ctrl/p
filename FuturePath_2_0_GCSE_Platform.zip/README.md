# FuturePath 2.0

A more complete GCSE platform prototype and full-stack starter.

## Included
- Student portal/dashboard
- Subject and topic explorer
- Career explorer with saved careers
- XP, levels, achievements and activity
- AI Study Coach interface
- Admin dashboard UI
- Existing Supabase/database starter
- Responsive mobile design

## Demo
Open `index.html` directly in a browser. Demo progress is stored in localStorage.

The admin screen is shown only when the demo account name is `Admin`, but this is NOT a security mechanism.

## Production architecture
Recommended:
- Frontend: Next.js/React or this frontend hosted on Vercel/Netlify
- Authentication/database: Supabase Auth + PostgreSQL
- AI: server-side/edge function
- Storage: Supabase Storage for revision files
- Analytics: database events with privacy-aware reporting

## Critical security
Frontend hiding is not access control. Admin permissions must be checked on the server/database.
Never put a private AI API key in client-side JavaScript.
For a school/under-18 deployment, implement safeguarding, privacy/retention rules, role separation, appropriate consent/notice and moderation processes before collecting real student data.

## Database
Use the supplied `supabase_schema.sql` from the starter package. The schema covers profiles, subjects, resources, careers, progress, saved careers, revision tasks and quiz attempts.
