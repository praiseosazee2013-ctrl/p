// Vercel/Node-style server endpoint.
// Install the OpenAI SDK on the server and set OPENAI_API_KEY in your host's secrets.
// NEVER put the API key in config.js or client-side JavaScript.

export default async function handler(req, res) {
  if (req.method !== "POST") return res.status(405).json({error:"Method not allowed"});
  const {prompt} = req.body || {};
  if (!prompt || typeof prompt !== "string" || prompt.length > 1200)
    return res.status(400).json({error:"Invalid prompt"});

  // Replace this section with your chosen AI provider.
  // Keep the secret server-side.
  if (!process.env.OPENAI_API_KEY)
    return res.status(501).json({error:"AI provider key is not configured on the server."});

  // Example shape only; wire this to your provider SDK/API in production.
  return res.status(200).json({
    answer: "AI endpoint is connected, but the provider call still needs to be implemented securely on the server."
  });
}